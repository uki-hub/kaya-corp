export default function LandingPage(props) {
  return <></>;
}

export async function getStaticProps(context) {
  return {
    props: {},
  };
}
